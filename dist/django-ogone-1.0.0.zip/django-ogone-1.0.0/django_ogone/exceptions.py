
class InvalidSignatureException(Exception):
    pass
    
class InvalidParamsException(Exception):
    pass
