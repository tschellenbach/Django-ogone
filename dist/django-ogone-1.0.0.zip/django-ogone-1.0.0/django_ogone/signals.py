from django.dispatch import Signal

ogone_update_order = Signal()
