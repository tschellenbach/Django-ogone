


__version__ = '1.0.0'
__maintainer__ = 'Thierry Schellenbach'
__email__ = 'thierryschellenbach at googles great mail service'